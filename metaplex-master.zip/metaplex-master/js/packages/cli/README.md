
Format

* Folder with files named from 0-1.png
* JSON file with attributes, format
    - Array with indices matching images
    - Contains: title, description and array of traits ({"display_type":"number","trait_type":"generation","value":2})


Install dependencies
```
yarn 
```


