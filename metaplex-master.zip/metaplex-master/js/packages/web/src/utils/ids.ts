import { PublicKey } from '@solana/web3.js';

// TODO: generate key ---
export const AR_SOL_HOLDER_ID = new PublicKey(
  'HvwC9QSAzvGXhhVrgPmauVwFWcYZhne3hVot9EbHuFTm',
);
