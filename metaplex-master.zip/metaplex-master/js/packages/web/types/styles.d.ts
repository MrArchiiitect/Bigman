// declaration.d.ts
declare module '*.module.less' {
  const content: Record<string, string>;
  export default content;
}
